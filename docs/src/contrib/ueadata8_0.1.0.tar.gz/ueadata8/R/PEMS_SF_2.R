#'
#' @title PEMS_SF_2
#' @description Multivariate time series (MTS) indicating occupancy rate of different car lanes.
#' @usage data(PEMS_SF_2)
#' @format A \code{list} with two elements, which are:
#' \describe{
#' \item{\code{data}}{A list with 220 MTS.}
#' \item{\code{classes}}{A numeric vector indicating the corresponding classes associated with the elements in \code{data}.}
#' }
#' @details Each element in \code{data} is a matrix formed by 144 rows (time points) indicating minutes and 3 columns (variables) indicating sensors.
#' The last 220 elements
#' of the whole dataset are stored here. The numeric vector \code{classes} is formed
#' by integers from 1 to 7, indicating that there are 7 different classes in the database. Each class is associated with a different
#' day of the week. For more information, see \insertCite{bagnall2018uea;textual}{mlmts}.
#' @references{
#'
#'   \insertRef{bagnall2018uea}{mlmts}
#'
#'   \insertRef{ruiz2021great}{mlmts}
#'
#'   \insertRef{bagnallweb}{mlmts}
#'
#' }
"PEMS_SF_2"

